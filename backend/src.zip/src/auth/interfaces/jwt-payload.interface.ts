export interface JwtPayload {
  sub: number;
  name: string;
}
